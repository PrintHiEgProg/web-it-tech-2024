(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_0cf6ee._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_0cf6ee._.js",
  "chunks": [
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_a91d55._.js",
    "static/chunks/node_modules_905a98._.js",
    "static/chunks/node_modules_refractor_f85e00._.js",
    "static/chunks/node_modules_react-syntax-highlighter_dist_d47cd2._.js",
    "static/chunks/node_modules_eee77b._.js",
    "static/chunks/src_app_page_tsx_32efbb._.js"
  ],
  "source": "dynamic"
});
